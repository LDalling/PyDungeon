tile_size = 16
tiles_x = 31
tiles_y = 31

def GetTiles():
    return tile_size, tiles_x, tiles_y
