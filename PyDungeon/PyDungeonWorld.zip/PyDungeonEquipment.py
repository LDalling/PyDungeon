import pygame
import random
import pyDungeonItems
import pyDungeonAbilities
class Equipment(PyDungeonItems)

    def __init__(self)
    Item.__init__(self)
    self.abilities = {}
